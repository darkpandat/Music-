package com.twh.rhythm_music

import com.ryanheise.audioservice.AudioServiceActivity

class MainActivity : AudioServiceActivity() {
}
