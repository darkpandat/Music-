* [Done] <s>Fix PlayerPane and add controller</s>
* [Done] <s>Fix & Complete Playlist pane</s>
* [Done] <s>Album Screen</s>
* [Done] <s> Playlist screen for items </s>
* [Partialy_completed] Search screen
* [Done] <s>Search result screen</s>
* [Done] Artist Screen
* [Partialy_completed] App Settings
* Housekeeping work
* Battery optimization disable option
* Album/Playlist Screen Modification (Bookmark, other playlist/Album details)

Playlist-
* Favourite
* [In_Progress] Offline
    * [Done] <s>cache imlementation</s>
    * <s>Handle Song</s> & image expiry

* [Done] <s>Theme based on thumbnail</s>
* [Done] <s>Background playing</s>
* [Done] <s>Notification Controls</s>
* Local Playlist Manangement



ui
[Partialy_completed]Shimmer effect on loading

Fix Required:
* [Done] <s>Pushing song to playlist</s>
* Code refactor

Priority Work:
* [done] Playlist remove & rename feature
* [done] Enqueue Song fix
* [done] Go to Album & View Artist Fix
* [done] Empty Playlist representation
* [done] Search header fix
* [done] Search artist list