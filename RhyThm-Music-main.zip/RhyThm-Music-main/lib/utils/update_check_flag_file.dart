// this file is intended to disbale update check for F-Droid build
// GitHub released apks are still be able to provide you new Version notification (will build locally after enabling this flag)
// If you want to enable update check please enable this flag locally & build your apk
const updateCheckFlag = false;
